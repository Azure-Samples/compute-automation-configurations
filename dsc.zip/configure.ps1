Configuration AzureDscDemo {
       Node Localhost {
           File DscFile {
               Type = "Directory"
               Ensure = "Present"
               DestinationPath = "C:\Scripts"
           }
      }
}